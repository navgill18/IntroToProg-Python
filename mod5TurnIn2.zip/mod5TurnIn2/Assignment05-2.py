# -------------------------------------------------#
# Title: Working with Dictionaries
# Dev:   RRoot
# Date:  July 16, 2012
# ChangeLog: (Who, When, What)
#   RRoot, 11/02/2016, Created starting template
#   <NAVDEEP GILL>, 10/26/2017, Added code to complete assignment 5
# https://www.tutorialspoint.com/python/python_dictionary.htm
# -------------------------------------------------#

# -- Data --#
# declare variables and constants
# objFile = An object that represents a file
objFile = open("C:\_PythonClass\module5\Todo.txt", "r")
strData = "" # A row of text data from the file
key = ""
val = ""
newKey = ""
newValue = ""
delKey = ""
delValue = ""
#When saving the values for the final time, this helps determine if the key is already in the file
valueExists = False
# dicRow = A row of data separated into elements of a dictionary {Task,Priority}
dicRow = {}
# lstTable = A dictionary that acts as a 'table' of rows
lstTable = []
# strChoice = Capture the user option selection
strChoice = ""

for currentLine in objFile:
    strData = currentLine
    dicRow = {(strData.split(',')[0]).strip(): (strData.split(',')[1].strip())}
    lstTable.append(dicRow)
print(lstTable)
# -- Input/Output --#
# User can see a Menu (Step 2)
# User can see data (Step 3)
# User can insert or delete data(Step 4 and 5)
# User can save to file (Step 6)

# -- Processing --#
# Step 1
# When the program starts, load the any data you have
# in a text file called ToDo.txt into a python Dictionary.
# Step 2
# Display a menu of choices to the user
while (strChoice.strip() != '5'):
    print("""
    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program
    """)
    strChoice = str(input("Which option would you like to perform? [1 to 5]: "))
    print()  # adding a new line

    # Step 3
    # Display all todo items to user
    if strChoice.strip() == '1':
        print("Here are the items currently saved:")
        print(dicRow)

    # Step 4
    # Add a new item to the list/Table
    elif strChoice.strip() == '2':
        newKey = input("What item is on your To Do list? ")
        if newKey not in dicRow:
            newValue = input("What's the priority level? ")
            dicRow = {newKey:newValue}
            lstTable.append(dicRow)
            print("\n", newKey, "has been added.")
        else:
            print("\nThat item is already on your list!")
    # Step 5
    # Remove a new item to the list/Table
    elif strChoice.strip() == '3':
        delKey = input("What item do you want to delete? ")
        if delKey in dicRow:
            delValue = dicRow[delKey]
            del dicRow[delKey]
            lstTable.remove(dicRow[delKey])
            print("\nYour item has been deleted.")
        else:
            print("That item is not in the dictionary/list!")
    elif strChoice.strip() == '4':
        objFile2 = open("C:\_PythonClass\module5\Todo.txt", "w")
        objFile2.write(str(lstTable))
        objFile2.close()
        print("\nThe tasks and priorities have been saved in the Todo.txt file")
    elif strChoice.strip() == '5':
        print("You are now done entering your items.")
    else:
        print("That option is not one of the ones listed in the menu!")
# Step 6
# Save tasks to the ToDo.txt file
print("The items in the list are now being saved to the file")
objFile2 = open("C:\_PythonClass\module5\Todo.txt", "w")
objFile2.write(str(lstTable))
objFile2.close()
# Step 7
# Exit program
print("\nItems from table have been saved.  The program is now done.  Thank you!")
# -------------------------------
'''
objFileName = "C:\_PythonClass\Todo.txt"
strData = ""
dicRow = {}
lstTable = []

# Step 1 - Load data from a file
# When the program starts, load each "row" of data
# in "ToDo.txt" into a python Dictionary.
# Add the each dictionary "row" to a python list "table"


# Step 2 - Display a menu of choices to the user
while (True):
    print("""
    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program
    """)
    strChoice = str(input("Which option would you like to perform? [1 to 4] - "))
    print()  # adding a new line

    # Step 3 -Show the current items in the table
    if (strChoice.strip() == '1'):
        continue
    # Step 4 - Add a new item to the list/Table
    elif (strChoice.strip() == '2'):
        continue
    # Step 5 - Remove a new item to the list/Table
    elif (strChoice == '3'):
        continue
    # Step 6 - Save tasks to the ToDo.txt file
    elif (strChoice == '4'):
        continue
    elif (strChoice == '5'):
        break  # and Exit the program

'''