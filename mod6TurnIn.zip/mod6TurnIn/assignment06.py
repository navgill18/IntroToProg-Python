# -------------------------------------------------#
# Title: Working with Dictionaries
# Dev:   RRoot
# Date:  July 16, 2012
# ChangeLog: (Who, When, What)
#   RRoot, 11/02/2016, Created starting template
#   <NAVDEEP GILL>, 10/26/2017, Added code to complete assignment 5
# https://www.tutorialspoint.com/python/python_dictionary.htm
# -------------------------------------------------#
# lstTable = A dictionary that acts as a 'table' of rows
lstTable = []
# dicRow = A row of data separated into elements of a dictionary {Task,Priority}
dicRow = {}
strData = ""  # A row of text data from the file
class ExecuteOption(object):

    @staticmethod
    def populateListTable(fileName):
        for currentLine in fileName:
            strData = currentLine
            dicRow = {(strData.split(',')[0]).strip(): (strData.split(',')[1].strip())}
            lstTable.append(dicRow)
        print("Current tasks in table: ")
        print(lstTable)
        return lstTable, dicRow

    @staticmethod
    def printTasks():
        print("Here are the items currently saved:")
        print(lstTable)

    @staticmethod
    def addTasks(addKey, addPriority):
        dicRow = {addKey:addPriority}
        lstTable.append(dicRow)

    @staticmethod
    def deleteTasks(deleteKey):
        for task in lstTable:
            if task == deleteKey:
                lstTable.remove(dicRow[deleteKey])
                print("\nYour item has been deleted.")

    @staticmethod
    def saveToFile():
        objFile2 = open("C:\_PythonClass\module5\Todo.txt", "w")
        objFile2.write(str(lstTable))
        objFile2.close()

def menu():
    print("""
            Menu of Options
            1) Show current data
            2) Add a new item.
            3) Remove an existing item.
            4) Save Data to File
            5) Exit Program
            """)
def introMessage():
    print("Welcome to the task prioritizer.  The following menu will be displayed to you each iteration:")
    menu()
    print("Just select the option number (such as 1 for show current data) to execute the command!")
    print("\n\n")

def readFileName():
    objFile = open("C:\_PythonClass\module5\Todo.txt", "r")
    return objFile



def getUserOption():
    strChoice = str(input("Which option would you like to perform? [1 to 5]: "))
    print()  # adding a new line
    return strChoice


def taskManager():
    userChoice = '0'
    while (userChoice.strip() != '5'):
        menu()
        userChoice = getUserOption()
        # Display all todo items to user
        if userChoice.strip() == '1':
            taskCreator.printTasks()
        # Add a new item to the list/Table
        elif userChoice.strip() == '2':
            newKey = input("What item is on your To Do list? ")
            if newKey not in dicRow:
                newValue = input("What's the priority level? ")
                taskCreator.addTasks(newKey, newValue)
                print("\n", newKey, "has been added.")
            else:
                print("\nThat item is already on your list!")
        # Remove a new item to the list/Table
        elif userChoice.strip() == '3':
            delKey = input("What item do you want to delete? ")
            if delKey in dicRow:
                taskCreator.deleteTasks(delKey)
            else:
                print("That item is not in the dictionary/list!")
        elif userChoice.strip() == '4':
            taskCreator.saveToFile()
            print("\nThe tasks and priorities have been saved in the Todo.txt file")
        elif userChoice.strip() == '5':
            print("You are now done entering your items.")
        else:
            print("That option is not one of the ones listed in the menu!")

def lastSave():
    print("The items in the list are now being saved to the file")
    objFile3 = open("C:\_PythonClass\module5\Todo.txt", "w")
    objFile3.write(str(lstTable))
    objFile3.close()

def exitMessage():
    print("\nItems from table have been saved.  The program is now done.  Thank you!")
userChoice = 0

#main
introMessage()
readVersionOfFile = readFileName()
taskCreator = ExecuteOption()
lstTable, dicRow = taskCreator.populateListTable(readVersionOfFile)
taskManager()
lastSave()
exitMessage()
# -------------------------------